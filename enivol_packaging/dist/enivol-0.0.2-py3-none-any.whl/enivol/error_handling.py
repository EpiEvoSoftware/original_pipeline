class CustomizedError(Exception):
    pass